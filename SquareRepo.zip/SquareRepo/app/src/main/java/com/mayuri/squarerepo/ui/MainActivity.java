package com.mayuri.squarerepo.ui;



import android.content.Context;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mayuri.squarerepo.MyApplication;
import com.mayuri.squarerepo.R;
import com.mayuri.squarerepo.adaptor.RecyclerViewAdapter;
import com.mayuri.squarerepo.di.component.ApplicationComponent;
import com.mayuri.squarerepo.di.component.DaggerMainActivityComponent;
import com.mayuri.squarerepo.di.component.MainActivityComponent;
import com.mayuri.squarerepo.di.module.MainActivityContextModule;
import com.mayuri.squarerepo.di.qualifier.ActivityContext;
import com.mayuri.squarerepo.di.qualifier.ApplicationContext;
import com.mayuri.squarerepo.pojo.SquareRepo;
import com.mayuri.squarerepo.retrofit.APIInterface;

import java.util.List;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements RecyclerViewAdapter.ClickListener {

    private RecyclerView recyclerView;
    MainActivityComponent mainActivityComponent;

    @Inject
    public RecyclerViewAdapter recyclerViewAdapter;

    @Inject
    public APIInterface apiInterface;

    @Inject
    @ApplicationContext
    public Context mContext;

    @Inject
    @ActivityContext
    public Context activityContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        ApplicationComponent applicationComponent = MyApplication.get(this).getApplicationComponent();
        mainActivityComponent = DaggerMainActivityComponent.builder()
                .mainActivityContextModule(new MainActivityContextModule(this))
                .applicationComponent(applicationComponent)
                .build();

        mainActivityComponent.injectMainActivity(this);
        recyclerView.setAdapter(recyclerViewAdapter);



        apiInterface.getSquareRepo().enqueue(new Callback<List<SquareRepo>>() {
            @Override
            public void onResponse(Call<List<SquareRepo>> call, Response<List<SquareRepo>> response) {
                //populateRecyclerView(response.body().setPermissions());

                List<SquareRepo> squareRepoList = response.body();

                String[] squareRepos = new String[squareRepoList.size()];

                for (int i = 0; i < squareRepoList.size(); i++) {
                    squareRepos[i] = squareRepoList.get(i).getName();
                }

                //displaying the string array into listview
              //  recyclerView.setAdapter(new ArrayAdapter<String>(getApplicationContext(), R.layout.square_repo_recyclerview, squareRepos));

            }

            @Override
            public void onFailure(Call<List<SquareRepo>> call, Throwable t) {

            }

        });

    }



    @Override
    public void launchIntent(String filmName) {

    }
}

