package com.mayuri.squarerepo.di.qualifier;

import javax.inject.Qualifier;


@Qualifier
public @interface ApplicationContext {

}
