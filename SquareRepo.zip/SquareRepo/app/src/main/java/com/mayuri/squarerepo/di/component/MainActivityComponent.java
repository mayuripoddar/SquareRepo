package com.mayuri.squarerepo.di.component;

import android.content.Context;

import com.mayuri.squarerepo.di.module.AdapterModule;
import com.mayuri.squarerepo.di.qualifier.ActivityContext;
import com.mayuri.squarerepo.di.scope.ActivityScope;
import com.mayuri.squarerepo.ui.MainActivity;

import dagger.Component;


@ActivityScope
@Component(modules = AdapterModule.class, dependencies = ApplicationComponent.class)
public interface MainActivityComponent {

    @ActivityContext
    Context getContext();


    void injectMainActivity(MainActivity mainActivity);
}
