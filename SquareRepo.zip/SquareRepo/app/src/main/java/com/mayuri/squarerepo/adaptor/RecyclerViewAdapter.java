package com.mayuri.squarerepo.adaptor;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;


import com.mayuri.squarerepo.R;
import com.mayuri.squarerepo.pojo.SquareRepo;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private List<SquareRepo> data;
    private RecyclerViewAdapter.ClickListener clickListener;

    @Inject
    public RecyclerViewAdapter(ClickListener clickListener) {
        this.clickListener = clickListener;
        data = new ArrayList<>();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.square_repo_recyclerview, parent, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        holder.id_textView.setText(data.get(position).getId());
        holder.name_textView.setText(data.get(position).getName());
        holder.forkCount_textView.setText(data.get(position).getForksCount());
        holder.watchers_textView.setText(data.get(position).getWatchers());
        holder.update_textView.setText(data.get(position).getUpdatedAt());
        holder.size_textView.setText(data.get(position).getSize());
        holder.weblink_textView.setText(data.get(position).getHtmlUrl());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private TextView id_textView;
        private TextView name_textView;
        private TextView forkCount_textView;
        private TextView watchers_textView;
        private TextView update_textView;
        private TextView size_textView;
        private TextView admin_textView;
        private TextView push_textView;
        private TextView pull_textView;
        private TextView weblink_textView;


        private ConstraintLayout constraintLayoutContainer;

        ViewHolder(View itemView) {
            super(itemView);

            id_textView =itemView.findViewById(R.id.id_textView);
            name_textView=itemView.findViewById(R.id.name_textView);
            forkCount_textView = itemView.findViewById(R.id.forkCount_textView);
            watchers_textView=itemView.findViewById(R.id.watchers_textView);
            update_textView=itemView.findViewById(R.id.update_textView);
            size_textView=itemView.findViewById(R.id.size_textView);
            admin_textView=itemView.findViewById(R.id.admin_textView);
            push_textView=itemView.findViewById(R.id.push_textView);
            pull_textView=itemView.findViewById(R.id.pull_textView);
            weblink_textView=itemView.findViewById(R.id.weblink_textView);



        }
    }

    public interface ClickListener {
        void launchIntent(String RepoName);
    }

    public void setData(List<SquareRepo> data) {
        this.data.addAll(data);
        notifyDataSetChanged();
    }
}
