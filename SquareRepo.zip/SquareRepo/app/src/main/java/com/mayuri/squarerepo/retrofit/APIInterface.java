package com.mayuri.squarerepo.retrofit;


import com.mayuri.squarerepo.pojo.SquareRepo;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface APIInterface {

    /*@GET
    Call<SquareRepo> getSquareRepo(@Query("format") String format);*/

    String BASE_URL = "https://api.github.com/orgs/square/";

    @GET("repos")
    Call<List<SquareRepo>> getSquareRepo();


   /* @GET("people/?")
    Call<StarWars> getPeople(@Query("format") String format);

    @GET
    Call<Film> getFilmData(@Url String url, @Query("format") String format);*/
}
